﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;
using SOaD.database;

namespace SOaD
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       public static database.SystemOfADownEntities connection = new database.SystemOfADownEntities();
        public static ObservableCollection<database.AgentInfo> agents { get; set; }
        public ObservableCollection<database.ProductionAgent> PrAg { get; set; }
        public static ObservableCollection<database.TypeOfAgent> Types { get; set; }=new ObservableCollection<database.TypeOfAgent>();

        public class SortList
        {
            public string NameS { get; set; }
            public string Description { get; set; }
            public bool Ascending { get; set; }
        }
        public ObservableCollection<SortList> FillSort { get; set; } = new ObservableCollection<SortList>
        {
            new SortList() { NameS = "Сбросить сортировку", Description=null, Ascending=true},
            new SortList() { NameS = "Сортировка по имени(возр.)", Description="NameAgent", Ascending=true},
            new SortList() { NameS = "Сортировка по имени(уб.)", Description="NameAgent", Ascending=false},
            new SortList() { NameS = "Сортировка по приоритету (возр.)", Description="Priority", Ascending=true},
            new SortList() { NameS = "Сортировка по приоритету (уб.)", Description="Priority", Ascending=false},
            new SortList() { NameS = "Сортировка по кол-ву продаж (возр.)", Description="Count", Ascending=true},
            new SortList() { NameS = "Сортировка по кол-ву продаж (уб.)", Description="Count", Ascending=false}
        };

        EditWindow editWindow = null;
        CreateWindow createWindow = null;


        public MainWindow()
        {
            InitializeComponent();

            agents = new ObservableCollection<database.AgentInfo>(connection.AgentInfo.ToList());
            Types.Add(new database.TypeOfAgent() { AgentType = "Все типы" });
            connection.TypeOfAgent.ToList().ForEach(m => {Types.Add(m); });
            DataContext = this;
            SortingCB.ItemsSource = FillSort;
            
            
            foreach(database.AgentInfo agent in agents)
            {
                agent.Count = 0;
                foreach (var a in agent.ProductionAgent)
                {
                    if (a.DateReal.Year == DateTime.Now.Year)
                    {
                        agent.Count += a.CountProduct;
                    }
                }

            }
            DataContext = this;
        }

        private void TB_TextChanged(object sender, TextChangedEventArgs e)
        {

            SearchFilter(TB.Text);
        }
        public void SearchFilter(string b)
        {
                ICollectionView view = CollectionViewSource.GetDefaultView(Oracul.ItemsSource);
                
                if (view == null)
                    return;
                view.Filter = new Predicate<object>(obj =>
                {
                    bool isView = ((database.AgentInfo)obj).NameAgent.ToLower().Contains(b.ToLower());
                    
                    return isView;
                }
                );
                
        }
        private void Sorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SortList a = SortingCB.SelectedItem as SortList;
            Sort(a.Description, a.Ascending);
        }

        public void Sort(string Description, bool Asc)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(Oracul.ItemsSource);
            if (view == null)
                return;
            view.SortDescriptions.Clear();
            if (Description != null)
            {
                view.SortDescriptions.Add(new SortDescription(Description, Asc ? ListSortDirection.Ascending : ListSortDirection.Descending));
            }
        }

        public void Filter(database.TypeOfAgent a)
        {
            ICollectionView view = CollectionViewSource.GetDefaultView(Oracul.ItemsSource);
            if (view == null)
                return;
            view.Filter = new Predicate<object>(obj =>
            {
                if (a.AgentType == "Все типы") return true;
                bool isView = ((database.AgentInfo)obj).AgTy== a.AgentType;
                return isView;
            });
            

        }

        private void Filtrating_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            database.TypeOfAgent a = FilterCB.SelectedItem as database.TypeOfAgent;
            Filter(a);

        }

        private void OpenAndEdit(object sender, SelectionChangedEventArgs e)
        {
            if (editWindow != null) return;
            editWindow = new EditWindow(Oracul.SelectedItem as database.AgentInfo);
            editWindow.Closed += EditWindow_Closed;
            editWindow.Show();
        }
        private void EditWindow_Closed(object sender,EventArgs e)
        {
            editWindow = null;
        }
        private void CreateWindow_Closed(object sender, EventArgs e)
        {
            createWindow = null;
        }

        private void AddNew(object sender, RoutedEventArgs e)
        {
            if (createWindow != null) return;
            createWindow = new CreateWindow();
            createWindow.Closed += CreateWindow_Closed;
            createWindow.Show();
            
        }
    }
}
