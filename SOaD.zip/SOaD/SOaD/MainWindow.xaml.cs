﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace SOaD
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        database.SystemOfADownEntities connection = new database.SystemOfADownEntities();
        public ObservableCollection<database.AgentInfo> agents { get; set; }
        public ObservableCollection<database.ProductionAgent> PrAg { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            agents = new ObservableCollection<database.AgentInfo>(connection.AgentInfo.ToList());
            
            foreach(database.AgentInfo agent in agents)
            {
                agent.Count = 0;
                foreach (var a in agent.ProductionAgent)
                {
                    if (a.DateReal.Year == DateTime.Now.Year)
                    {
                        agent.Count += a.CountProduct;
                    }
                }

            }
            DataContext = this;
        }

        private void TB_TextChanged(object sender, TextChangedEventArgs e)
        {

            SearchFilter(TB.Text);
        }
        public void SearchFilter(string b)
        {
                ICollectionView view = CollectionViewSource.GetDefaultView(Oracul.ItemsSource);
                
                if (view == null)
                    return;
                view.Filter = new Predicate<object>(obj =>
                {
                    bool isView = ((database.AgentInfo)obj).NameAgent.ToLower().Contains(b.ToLower());
                    
                    return isView;
                }
                );
                
        }
    }
}
