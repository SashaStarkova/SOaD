﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SOaD.database
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        public database.AgentInfo AgentInfo { get; set; }
        
        public EditWindow(database.AgentInfo agentInfo)
        {
            InitializeComponent();
            AgentInfo = agentInfo;
            Type.SetBinding(ComboBox.ItemsSourceProperty, new Binding()
            {
                Source = MainWindow.Types
            });
            DataContext = this;
        }

        private void DelAg(object sender, RoutedEventArgs e)
        {
            MainWindow.connection.ProductionAgent.RemoveRange(AgentInfo.ProductionAgent);
            MainWindow.connection.AgentInfo.Remove(AgentInfo);
            MainWindow.connection.SaveChanges();
            MainWindow.agents.Remove(AgentInfo);
            Close();

        }        

        private void SaveAg(object sender, RoutedEventArgs e)
        {
            MainWindow.connection.SaveChanges();
            Close();
        }
    }
}
